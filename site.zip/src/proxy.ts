import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import * as jose from "jose";
import { cookies } from "next/headers";

// Optimization: Pre-encode the secret outside the function
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET);

export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  const cookieStore = await cookies();

  const accessToken = cookieStore.get("accessToken")?.value;
  const refreshToken = cookieStore.get("refreshToken")?.value;

  if (!accessToken && !refreshToken) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  try {
    const accessTokenDecoded = await jose.jwtVerify(
      accessToken as string,
      JWT_SECRET,
    );

    if (
      accessTokenDecoded.payload.role === "admin" &&
      pathname === "/dashboard"
    ) {
      return NextResponse.next();
    }

    if (pathname === "/login") {
      return NextResponse.redirect(new URL("/dashboard", request.url));
    }
  } catch (error) {
    console.log("Moving to refresh token", error);
    try {
      const refreshTokenDecoded = await jose.jwtVerify(
        refreshToken as string,
        JWT_SECRET,
      );

      if (
        refreshTokenDecoded.payload.role === "admin" &&
        pathname === "/dashboard"
      ) {
        return NextResponse.next();
      }

      if (pathname === "/login") {
        return NextResponse.redirect(new URL("/dashboard", request.url));
      }
    } catch (error) {
      console.log("Moving to login", error);
      return NextResponse.redirect(new URL("/login", request.url));
    }
  }
}

export const config = {
  matcher: ["/dashboard/:path*", "/login"],
};
