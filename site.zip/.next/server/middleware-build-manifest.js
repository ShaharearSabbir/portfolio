globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/KjnRpq6ONwwBBH5E_B6ux/_buildManifest.js",
    "static/KjnRpq6ONwwBBH5E_B6ux/_ssgManifest.js",
    "static/KjnRpq6ONwwBBH5E_B6ux/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yb2wil16uz6h.js",
    "static/chunks/0~-sl6f.l6gsn.js",
    "static/chunks/0jey8v~l7t24_.js",
    "static/chunks/0.m6_yc1k8acz.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0r7m44~cm1a3r.js",
    "static/chunks/turbopack-0pokopd5c2usz.js"
  ]
};
