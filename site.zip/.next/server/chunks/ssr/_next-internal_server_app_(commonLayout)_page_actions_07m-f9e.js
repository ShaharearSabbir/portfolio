module.exports=[2872,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28commonLayout%29_page_actions_07m-f9e.js.map